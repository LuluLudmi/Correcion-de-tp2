package segundaactividad.aguadagilma.test;

import segundaactividad.aguadagilma.entidades.ConcesionariaService;
import java.util.Scanner;

/**
 * Clase principal que simula el funcionamiento de la concesionaria.
 * Contiene el método main para ejecutar la aplicación y mostrar la salida por consola.
 */
public class Concesionaria {

    public static void main(String[] args) {
        ConcesionariaService concesionariaService = new ConcesionariaService();
        Scanner teclado = new Scanner(System.in);

        // 1. Mostrar la lista inicial de vehículos
        concesionariaService.mostrarListaInicialDeVehiculos();

        // 2. Mostrar el vehículo más caro
        concesionariaService.mostrarVehiculoMasCaro();

        // 3. Mostrar el vehículo más barato
        concesionariaService.mostrarVehiculoMasBarato();

        // 4. Pedir letra y mostrar vehículo que la contiene en su modelo
        System.out.print("Ingrese la letra a buscar en los modelos de vehículos: ");
        String letraABuscar = teclado.next();
        concesionariaService.mostrarVehiculoPorLetraEnModelo(letraABuscar);

        // 5. Mostrar vehículos ordenados por precio descendente
        concesionariaService.mostrarVehiculosOrdenadosPorPrecioDescendente();

        // 6. Mostrar vehículos ordenados por orden natural
        concesionariaService.mostrarVehiculosOrdenadosPorOrdenNatural();

        teclado.close();
    }
}