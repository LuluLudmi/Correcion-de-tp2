package segundaactividad.aguadagilma.entidades;

import lombok.Getter;

@Getter
public class Auto extends Vehiculo {
    private int puertas;

    public Auto(String marca, String modelo, double precio, int puertas) {
        super(marca, modelo, precio);
        this.puertas = puertas;
    }

    @Override
    protected String getDetallesEspecificos() {
        return " // Puertas: " + puertas;
    }
}