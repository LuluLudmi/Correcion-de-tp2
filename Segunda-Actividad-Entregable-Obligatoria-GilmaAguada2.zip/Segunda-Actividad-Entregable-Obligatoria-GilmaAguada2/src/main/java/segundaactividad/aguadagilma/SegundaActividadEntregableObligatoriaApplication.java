package segundaactividad.aguadagilma;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SegundaActividadEntregableObligatoriaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SegundaActividadEntregableObligatoriaApplication.class, args);
	}

}
